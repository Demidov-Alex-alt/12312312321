class Publisher:
    def __init__(self, name, location):
        self.name = name
        self.location = location

    def get_info(self):
        print("Название издательства:", self.name)
        print("Расположение издательства:", self.location)

    def publish(self, message):
        print("Издательство", self.name, "печатает:", message)


class BookPublisher(Publisher):
    def __init__(self, name, location, num_authors):
        super().__init__(name, location)
        self.num_authors = num_authors

    def publish(self, title, author):
        super().publish("Книга: {} (Автор: {})".format(title, author))
        print("Количество авторов:", self.num_authors)


class NewspaperPublisher(Publisher):
    def __init__(self, name, location, num_pages):
        super().__init__(name, location)
        self.num_pages = num_pages

    def publish(self, headline):
        super().publish("Главная статья: {}".format(headline))
        print("Количество страниц:", self.num_pages)


# пример


publisher = Publisher("АБВГД Пресс", "Москва")
publisher.get_info()
publisher.publish("Справочник писателя")

book_publisher = BookPublisher("Важные Книги", "Самара", 52)
book_publisher.get_info()
book_publisher.publish("Приключения Чебурашки", "В.И. Пупкин")

newspaper_publisher = NewspaperPublisher("Московские вести", "Москва", 12)
newspaper_publisher.get_info()
newspaper_publisher.publish("Новая версия Midjourney будет платной")
