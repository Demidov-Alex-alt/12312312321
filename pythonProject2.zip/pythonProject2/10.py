class Soldier:
    def __init__(self, name, rank, service_number):
        self.name = name
        self.__rank = rank
        self.__service_number = service_number

    def get_rank(self):
        return self.__rank

    def confirm_service_number(self, number):
        return number == self.__service_number

    def promote(self):
        ranks = ['рядовой', 'ефрейтор', 'мл. сержант', 'сержант', 'ст. сержант', 'старшина', 'прапорщик', 'ст. прапорщик',
                 'мл. лейтенант', 'лейтенант', 'ст. лейтенант', 'капитан', 'майор', 'подполковник', 'полковник']
        current_rank_index = ranks.index(self.__rank)
        if current_rank_index < len(ranks) - 1:
            self.__rank = ranks[current_rank_index + 1]
            return True
        else:
            return False

    def demote(self):
        ranks = ['рядовой', 'ефрейтор', 'мл. сержант', 'сержант', 'ст. сержант', 'старшина', 'прапорщик', 'ст. прапорщик',
                 'мл. лейтенант', 'лейтенант', 'ст. лейтенант', 'капитан', 'майор', 'подполковник', 'полковник']
        current_rank_index = ranks.index(self.__rank)
        if current_rank_index > 0:
            self.__rank = ranks[current_rank_index - 1]
            return True
        else:
            return False

# Пример


soldier1 = Soldier("Иван Сусанин", "рядовой", "12345")
print(soldier1.get_rank())  
print(soldier1.confirm_service_number("12345"))
print(soldier1.promote())
print(soldier1.get_rank())
print(soldier1.demote())
print(soldier1.get_rank())