class BankAccount:
    def __init__(self, balance, interest_rate):
        self.__balance = balance
        self.__interest_rate = interest_rate
        self.__transactions = []

    def deposit(self, amount):
        self.__balance += amount
        self.__transactions.append(f"Deposit: +{amount}")

    def withdraw(self, amount):
        if self.__balance >= amount:
            self.__balance -= amount
            self.__transactions.append(f"Withdrawal: -{amount}")
        else:
            print("Insufficient funds.")

    def add_interest(self):
        interest = self.__balance * self.__interest_rate
        self.__balance += interest
        self.__transactions.append(f"Interest: +{interest}")

    def history(self):
        for transaction in self.__transactions:
            print(transaction)


# пример


account = BankAccount(100000, 0.05)
account.deposit(15000)
account.withdraw(7500)
account.add_interest()
account.history()
