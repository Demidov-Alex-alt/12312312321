class Employee:
    def __init__(self, name, age, salary):
        self.name = name
        self.age = age
        self.salary = salary
        self.bonus = 0

    def set_bonus(self, bonus):
        self.bonus = bonus

    def get_name(self):
        return self.name

    def get_age(self):
        return self.age

    def get_salary(self):
        return self.salary

    def get_bonus(self):
        return self.bonus

    def get_total_salary(self):
        return self.salary + self.bonus


# пример


employee = Employee("Марина Арефьева", 30, 90000)
employee.set_bonus(15000)

print("Имя:", employee.get_name())
print("Возраст:", employee.get_age())
print("Зарплата:", employee.get_salary())
print("Бонус:", employee.get_bonus())
print("Итого начислено:", employee.get_total_salary())
