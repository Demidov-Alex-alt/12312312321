class Animal:
    def __init__(self, name, species, legs):
        self.name = name
        self.species = species
        self.legs = legs

    def voice(self):
        print(f"{self.name} говорит: ...")

    def move(self):
        print(f"{self.name} двигается...")


class Dog(Animal):
    def __init__(self, name, species, legs, breed):
        super().__init__(name, species, legs)
        self.breed = breed

    def bark(self):
        print(f"{self.name} лает: Гав-гав!")

    def voice(self):
        print(f"{self.name} говорит: Гав!")


class Bird(Animal):
    def __init__(self, name, species, legs, wingspan):
        super().__init__(name, species, legs)
        self.wingspan = wingspan

    def fly(self):
        print(f"{self.name} летит!")

    def voice(self):
        print(f"{self.name} говорит: Чирик!")


# пример


dog = Dog("Геральт", "доберман", 4, "Доберман")
bird = Bird("Вася", "попугай", 2, 30)

dog.voice()
bird.voice()
dog.move()
bird.move()
dog.bark()
bird.fly()
